import React from 'react';
import { Lightbulb, Bus, Leaf, Plug, ArrowRight, Sparkles } from 'lucide-react';
import { ecoTips } from '../data/mockData';

export const EcoTips: React.FC = () => {
  const iconMap = {
    Bus: Bus,
    Lightbulb: Lightbulb,
    Leaf: Leaf,
    Plug: Plug
  };

  const categoryColors = {
    Transport: 'bg-red-100 text-red-600 border-red-200',
    Energy: 'bg-yellow-100 text-yellow-600 border-yellow-200',
    Food: 'bg-green-100 text-green-600 border-green-200',
    Lifestyle: 'bg-blue-100 text-blue-600 border-blue-200'
  };

  const totalPotentialSavings = ecoTips.reduce((sum, tip) => sum + tip.potentialSavings, 0);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900">Eco-Friendly Tips</h2>
        <p className="text-gray-600 mt-2">Simple changes that make a big environmental impact</p>
      </div>

      {/* Impact Summary */}
      <div className="bg-gradient-to-r from-emerald-400 to-teal-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">Your Potential Monthly Impact</h3>
            <p className="text-3xl font-bold">{totalPotentialSavings.toFixed(1)} kg CO₂</p>
            <p className="text-emerald-100">saved by following all tips</p>
          </div>
          <div className="p-4 bg-white bg-opacity-20 rounded-lg">
            <Sparkles className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      {/* Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {ecoTips.map((tip) => {
          const IconComponent = iconMap[tip.icon as keyof typeof iconMap] || Lightbulb;
          const colorClass = categoryColors[tip.category as keyof typeof categoryColors] || categoryColors.Energy;
          
          return (
            <div key={tip.id} className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 group">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-lg ${colorClass} border`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors">
                      {tip.title}
                    </h3>
                    <span className="text-xs font-medium text-emerald-600 bg-emerald-100 px-2 py-1 rounded-full">
                      {tip.category}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-4 leading-relaxed">{tip.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="text-2xl font-bold text-emerald-600">{tip.potentialSavings.toFixed(1)}</div>
                      <div className="text-sm text-gray-500">
                        <div>kg CO₂</div>
                        <div>per month</div>
                      </div>
                    </div>
                    <button className="flex items-center space-x-2 text-emerald-600 hover:text-emerald-700 font-medium group-hover:translate-x-1 transition-all duration-200">
                      <span>Learn More</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-gray-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions for Today</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4 border border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <Bus className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Walk or Bike</p>
                <p className="text-sm text-gray-600">Save 2.3 kg CO₂</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 border border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Lightbulb className="h-5 w-5 text-yellow-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">LED Bulbs</p>
                <p className="text-sm text-gray-600">Save 0.4 kg CO₂</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 border border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Leaf className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Plant-Based Meal</p>
                <p className="text-sm text-gray-600">Save 1.8 kg CO₂</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 border border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Plug className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">Unplug Devices</p>
                <p className="text-sm text-gray-600">Save 0.3 kg CO₂</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
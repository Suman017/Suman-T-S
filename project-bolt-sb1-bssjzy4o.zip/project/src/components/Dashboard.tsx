import React from 'react';
import { BarChart3, TrendingDown, Target, Calendar } from 'lucide-react';
import { mockWeeklyEmissions, mockGoals } from '../data/mockData';

export const Dashboard: React.FC = () => {
  const todayEmissions = mockWeeklyEmissions[mockWeeklyEmissions.length - 1];
  const weekTotal = mockWeeklyEmissions.reduce((sum, day) => sum + day.total, 0);
  const avgDaily = weekTotal / mockWeeklyEmissions.length;
  const completedGoals = mockGoals.filter(goal => goal.isCompleted).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Your Carbon Dashboard</h1>
        <p className="text-lg text-gray-600">Track, reduce, and offset your environmental impact</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Emissions</p>
              <p className="text-2xl font-bold text-gray-900">{todayEmissions.total.toFixed(1)} kg</p>
              <p className="text-xs text-emerald-600 font-medium">CO₂ equivalent</p>
            </div>
            <div className="p-3 bg-emerald-100 rounded-lg">
              <BarChart3 className="h-6 w-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Weekly Average</p>
              <p className="text-2xl font-bold text-gray-900">{avgDaily.toFixed(1)} kg</p>
              <p className="text-xs text-teal-600 font-medium">per day</p>
            </div>
            <div className="p-3 bg-teal-100 rounded-lg">
              <Calendar className="h-6 w-6 text-teal-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Reduction Goal</p>
              <p className="text-2xl font-bold text-gray-900">-18%</p>
              <p className="text-xs text-blue-600 font-medium">vs last month</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <TrendingDown className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow duration-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Goals Completed</p>
              <p className="text-2xl font-bold text-gray-900">{completedGoals}/{mockGoals.length}</p>
              <p className="text-xs text-amber-600 font-medium">this month</p>
            </div>
            <div className="p-3 bg-amber-100 rounded-lg">
              <Target className="h-6 w-6 text-amber-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Emissions Chart */}
      <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Weekly Emissions Breakdown</h3>
        <div className="space-y-4">
          {mockWeeklyEmissions.map((day, index) => {
            const date = new Date(day.date);
            const maxEmission = Math.max(...mockWeeklyEmissions.map(d => d.total));
            
            return (
              <div key={day.date} className="group">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">
                    {date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                  </span>
                  <span className="text-sm text-gray-600">{day.total.toFixed(1)} kg CO₂</span>
                </div>
                <div className="flex space-x-1 h-6 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="bg-red-400 transition-all duration-300 group-hover:bg-red-500"
                    style={{ width: `${(day.transport / day.total) * 100}%` }}
                    title={`Transport: ${day.transport.toFixed(1)} kg`}
                  />
                  <div 
                    className="bg-yellow-400 transition-all duration-300 group-hover:bg-yellow-500"
                    style={{ width: `${(day.energy / day.total) * 100}%` }}
                    title={`Energy: ${day.energy.toFixed(1)} kg`}
                  />
                  <div 
                    className="bg-green-400 transition-all duration-300 group-hover:bg-green-500"
                    style={{ width: `${(day.food / day.total) * 100}%` }}
                    title={`Food: ${day.food.toFixed(1)} kg`}
                  />
                  <div 
                    className="bg-blue-400 transition-all duration-300 group-hover:bg-blue-500"
                    style={{ width: `${(day.lifestyle / day.total) * 100}%` }}
                    title={`Lifestyle: ${day.lifestyle.toFixed(1)} kg`}
                  />
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Legend */}
        <div className="flex flex-wrap gap-4 mt-6 pt-4 border-t border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-400 rounded-full"></div>
            <span className="text-sm text-gray-600">Transport</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
            <span className="text-sm text-gray-600">Energy</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <span className="text-sm text-gray-600">Food</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
            <span className="text-sm text-gray-600">Lifestyle</span>
          </div>
        </div>
      </div>
    </div>
  );
};
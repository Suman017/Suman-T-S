import React, { useState } from 'react';
import { Target, Trophy, Plus, Calendar, TrendingDown } from 'lucide-react';
import { mockGoals } from '../data/mockData';
import { Goal } from '../types';

export const Goals: React.FC = () => {
  const [goals, setGoals] = useState<Goal[]>(mockGoals);
  const [showForm, setShowForm] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    targetReduction: 0,
    deadline: ''
  });

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    
    const goal: Goal = {
      id: Date.now().toString(),
      title: newGoal.title,
      targetReduction: newGoal.targetReduction,
      currentProgress: 0,
      deadline: new Date(newGoal.deadline),
      isCompleted: false
    };

    setGoals([...goals, goal]);
    setNewGoal({ title: '', targetReduction: 0, deadline: '' });
    setShowForm(false);
  };

  const completedGoals = goals.filter(goal => goal.isCompleted);
  const activeGoals = goals.filter(goal => !goal.isCompleted);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Sustainability Goals</h2>
          <p className="text-gray-600 mt-1">Set targets and track your progress toward a greener lifestyle</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg transition-colors duration-200"
        >
          <Plus className="h-4 w-4" />
          <span>New Goal</span>
        </button>
      </div>

      {/* Goals Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-6 border border-emerald-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-emerald-200 rounded-lg">
              <Target className="h-6 w-6 text-emerald-700" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{activeGoals.length}</p>
              <p className="text-sm text-gray-600">Active Goals</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-6 border border-amber-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-amber-200 rounded-lg">
              <Trophy className="h-6 w-6 text-amber-700" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{completedGoals.length}</p>
              <p className="text-sm text-gray-600">Completed</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-200 rounded-lg">
              <TrendingDown className="h-6 w-6 text-blue-700" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {goals.reduce((sum, goal) => sum + goal.targetReduction, 0)}%
              </p>
              <p className="text-sm text-gray-600">Total Reduction Target</p>
            </div>
          </div>
        </div>
      </div>

      {/* Add Goal Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Create New Goal</h3>
            <form onSubmit={handleAddGoal} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Goal Title</label>
                <input
                  type="text"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  placeholder="e.g., Reduce car usage by cycling more"
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Reduction (%)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={newGoal.targetReduction}
                  onChange={(e) => setNewGoal({ ...newGoal, targetReduction: parseInt(e.target.value) })}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Date</label>
                <input
                  type="date"
                  value={newGoal.deadline}
                  onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-lg transition-colors duration-200"
                >
                  Create Goal
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors duration-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Active Goals */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-gray-900">Active Goals</h3>
        <div className="grid gap-4">
          {activeGoals.map((goal) => {
            const daysLeft = Math.ceil((goal.deadline.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
            const isOverdue = daysLeft < 0;
            
            return (
              <div key={goal.id} className="bg-white rounded-lg p-6 shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-lg">{goal.title}</h4>
                    <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                      <span className="flex items-center">
                        <Target className="h-4 w-4 mr-1" />
                        {goal.targetReduction}% reduction
                      </span>
                      <span className={`flex items-center ${isOverdue ? 'text-red-600' : 'text-gray-600'}`}>
                        <Calendar className="h-4 w-4 mr-1" />
                        {isOverdue ? `${Math.abs(daysLeft)} days overdue` : `${daysLeft} days left`}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-emerald-600">{goal.currentProgress}%</p>
                    <p className="text-xs text-gray-500">completed</p>
                  </div>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                  <div 
                    className="bg-gradient-to-r from-emerald-400 to-teal-500 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(goal.currentProgress, 100)}%` }}
                  />
                </div>
                
                <div className="flex justify-between text-xs text-gray-500">
                  <span>0%</span>
                  <span>{goal.targetReduction}% target</span>
                  <span>100%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Completed Goals */}
      {completedGoals.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-900">Completed Goals</h3>
          <div className="grid gap-4">
            {completedGoals.map((goal) => (
              <div key={goal.id} className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg p-6 border border-emerald-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-emerald-200 rounded-lg">
                      <Trophy className="h-5 w-5 text-emerald-700" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{goal.title}</h4>
                      <p className="text-sm text-gray-600">{goal.targetReduction}% reduction achieved</p>
                    </div>
                  </div>
                  <div className="text-emerald-600 font-semibold">✓ Completed</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
import React, { useState } from 'react';
import { Plus, Car, Zap, Utensils, ShoppingBag, Calendar, Calculator } from 'lucide-react';
import { Activity } from '../types';
import { mockActivities } from '../data/mockData';

export const ActivityTracker: React.FC = () => {
  const [activities, setActivities] = useState<Activity[]>(mockActivities);
  const [showForm, setShowForm] = useState(false);
  const [newActivity, setNewActivity] = useState({
    type: 'transport' as Activity['type'],
    category: '',
    description: '',
    amount: 0,
    unit: ''
  });

  const categoryIcons = {
    transport: Car,
    energy: Zap,
    food: Utensils,
    lifestyle: ShoppingBag
  };

  const categoryColors = {
    transport: 'bg-red-100 text-red-600',
    energy: 'bg-yellow-100 text-yellow-600',
    food: 'bg-green-100 text-green-600',
    lifestyle: 'bg-blue-100 text-blue-600'
  };

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple carbon footprint calculation (simplified for demo)
    const carbonFactors = {
      transport: 0.23, // kg CO2 per km
      energy: 0.48,    // kg CO2 per kWh
      food: 2.5,       // kg CO2 per kg (varies by food type)
      lifestyle: 1.6   // kg CO2 per item (simplified)
    };

    const carbonFootprint = newActivity.amount * carbonFactors[newActivity.type];

    const activity: Activity = {
      id: Date.now().toString(),
      ...newActivity,
      carbonFootprint,
      date: new Date()
    };

    setActivities([activity, ...activities]);
    setNewActivity({
      type: 'transport',
      category: '',
      description: '',
      amount: 0,
      unit: ''
    });
    setShowForm(false);
  };

  const todayActivities = activities.filter(
    activity => activity.date.toDateString() === new Date().toDateString()
  );

  const totalTodayEmissions = todayActivities.reduce((sum, activity) => sum + activity.carbonFootprint, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Activity Tracker</h2>
          <p className="text-gray-600 mt-1">Record your daily activities and their carbon impact</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg transition-colors duration-200"
        >
          <Plus className="h-4 w-4" />
          <span>Add Activity</span>
        </button>
      </div>

      {/* Today's Summary */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-6 border border-emerald-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Today's Impact</h3>
            <p className="text-3xl font-bold text-emerald-600 mt-1">{totalTodayEmissions.toFixed(1)} kg CO₂</p>
            <p className="text-sm text-gray-600">{todayActivities.length} activities recorded</p>
          </div>
          <div className="p-3 bg-emerald-200 rounded-lg">
            <Calculator className="h-8 w-8 text-emerald-700" />
          </div>
        </div>
      </div>

      {/* Add Activity Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Add New Activity</h3>
            <form onSubmit={handleAddActivity} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  value={newActivity.type}
                  onChange={(e) => setNewActivity({ ...newActivity, type: e.target.value as Activity['type'] })}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                >
                  <option value="transport">Transport</option>
                  <option value="energy">Energy</option>
                  <option value="food">Food</option>
                  <option value="lifestyle">Lifestyle</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Specific Category</label>
                <input
                  type="text"
                  value={newActivity.category}
                  onChange={(e) => setNewActivity({ ...newActivity, category: e.target.value })}
                  placeholder="e.g., Car, Electricity, Beef"
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <input
                  type="text"
                  value={newActivity.description}
                  onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })}
                  placeholder="Brief description"
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="flex space-x-2">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newActivity.amount}
                    onChange={(e) => setNewActivity({ ...newActivity, amount: parseFloat(e.target.value) })}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                  <input
                    type="text"
                    value={newActivity.unit}
                    onChange={(e) => setNewActivity({ ...newActivity, unit: e.target.value })}
                    placeholder="km, kWh, kg"
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-lg transition-colors duration-200"
                >
                  Add Activity
                </button>
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors duration-200"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Activities List */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-gray-900">Recent Activities</h3>
        <div className="grid gap-4">
          {activities.slice(0, 10).map((activity) => {
            const IconComponent = categoryIcons[activity.type];
            const colorClass = categoryColors[activity.type];
            
            return (
              <div key={activity.id} className="bg-white rounded-lg p-4 shadow-md border border-gray-100 hover:shadow-lg transition-shadow duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${colorClass}`}>
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{activity.description}</h4>
                      <p className="text-sm text-gray-600">
                        {activity.category} • {activity.amount} {activity.unit}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{activity.carbonFootprint.toFixed(1)} kg CO₂</p>
                    <p className="text-xs text-gray-500 flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {activity.date.toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
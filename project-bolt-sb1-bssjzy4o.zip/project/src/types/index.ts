export interface Activity {
  id: string;
  type: 'transport' | 'energy' | 'food' | 'lifestyle';
  category: string;
  description: string;
  amount: number;
  unit: string;
  carbonFootprint: number; // kg CO2
  date: Date;
}

export interface Goal {
  id: string;
  title: string;
  targetReduction: number; // percentage
  currentProgress: number; // percentage
  deadline: Date;
  isCompleted: boolean;
}

export interface DailyEmission {
  date: string;
  transport: number;
  energy: number;
  food: number;
  lifestyle: number;
  total: number;
}

export interface EcoTip {
  id: string;
  title: string;
  description: string;
  category: string;
  potentialSavings: number; // kg CO2 per month
  icon: string;
}
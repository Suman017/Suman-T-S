import { Activity, Goal, DailyEmission, EcoTip } from '../types';

export const mockActivities: Activity[] = [
  {
    id: '1',
    type: 'transport',
    category: 'Car',
    description: 'Commute to work',
    amount: 25,
    unit: 'km',
    carbonFootprint: 5.75,
    date: new Date('2025-01-07')
  },
  {
    id: '2',
    type: 'energy',
    category: 'Electricity',
    description: 'Home electricity usage',
    amount: 15,
    unit: 'kWh',
    carbonFootprint: 7.2,
    date: new Date('2025-01-07')
  },
  {
    id: '3',
    type: 'food',
    category: 'Meat',
    description: 'Beef consumption',
    amount: 0.5,
    unit: 'kg',
    carbonFootprint: 13.5,
    date: new Date('2025-01-07')
  },
  {
    id: '4',
    type: 'lifestyle',
    category: 'Shopping',
    description: 'Online purchases',
    amount: 2,
    unit: 'items',
    carbonFootprint: 3.2,
    date: new Date('2025-01-06')
  }
];

export const mockGoals: Goal[] = [
  {
    id: '1',
    title: 'Reduce Transportation Emissions',
    targetReduction: 30,
    currentProgress: 45,
    deadline: new Date('2025-06-01'),
    isCompleted: false
  },
  {
    id: '2',
    title: 'Switch to Renewable Energy',
    targetReduction: 50,
    currentProgress: 80,
    deadline: new Date('2025-03-01'),
    isCompleted: false
  },
  {
    id: '3',
    title: 'Plant-Based Diet 3 Days/Week',
    targetReduction: 25,
    currentProgress: 100,
    deadline: new Date('2025-02-01'),
    isCompleted: true
  }
];

export const mockWeeklyEmissions: DailyEmission[] = [
  { date: '2025-01-01', transport: 8.2, energy: 6.5, food: 12.3, lifestyle: 4.1, total: 31.1 },
  { date: '2025-01-02', transport: 5.1, energy: 7.2, food: 15.8, lifestyle: 2.9, total: 31.0 },
  { date: '2025-01-03', transport: 12.4, energy: 5.8, food: 8.7, lifestyle: 6.3, total: 33.2 },
  { date: '2025-01-04', transport: 6.7, energy: 8.1, food: 11.2, lifestyle: 3.5, total: 29.5 },
  { date: '2025-01-05', transport: 9.3, energy: 6.9, food: 14.1, lifestyle: 4.8, total: 35.1 },
  { date: '2025-01-06', transport: 4.2, energy: 7.8, food: 9.6, lifestyle: 5.2, total: 26.8 },
  { date: '2025-01-07', transport: 5.8, energy: 7.2, food: 13.5, lifestyle: 3.2, total: 29.7 }
];

export const ecoTips: EcoTip[] = [
  {
    id: '1',
    title: 'Use Public Transport',
    description: 'Switch to public transport or cycling for daily commutes to reduce carbon emissions.',
    category: 'Transport',
    potentialSavings: 45.5,
    icon: 'Bus'
  },
  {
    id: '2',
    title: 'LED Light Bulbs',
    description: 'Replace traditional bulbs with LED lights to reduce energy consumption by up to 80%.',
    category: 'Energy',
    potentialSavings: 12.3,
    icon: 'Lightbulb'
  },
  {
    id: '3',
    title: 'Reduce Meat Consumption',
    description: 'Try plant-based meals 2-3 times per week to significantly lower your food carbon footprint.',
    category: 'Food',
    potentialSavings: 28.7,
    icon: 'Leaf'
  },
  {
    id: '4',
    title: 'Unplug Electronics',
    description: 'Unplug devices when not in use to eliminate phantom energy consumption.',
    category: 'Energy',
    potentialSavings: 8.9,
    icon: 'Plug'
  }
];